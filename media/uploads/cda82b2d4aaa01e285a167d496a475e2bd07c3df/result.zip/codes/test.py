str1 = '1'
str2 = '2'
str3 = str1 + ' ' +str2
print(str3)